clear all
close all
define
kappa_tab=[3];
coor0=[0,0];
coor1=2*[cos(pi/6) sin(pi/6)];
coor2=2*[cos(pi/6) -sin(pi/6)];
coor3=2*[0,-1];
coor4=2*[-cos(pi/6),-sin(pi/6)];
coor5=2*[-cos(pi/6) sin(pi/6)];
coor6=[0,2];
%coor0=[0 0]; % Coordinate of the center of the first cell
%coor1=[sqrt(3)/2 1]; % Coordinate of the center of the fourth cell
%coor2=[sqrt(3)/2 -1]; % Coordinate of the center of the fifth cell

coor_cells={coor0,coor1,coor2,coor3,coor4,coor5,coor6}


plot(coor_cells{1}(1),coor_cells{1}(2),'r+');
hold on
plot(coor_cells{2}(1),coor_cells{2}(2),'r+');
plot(coor_cells{3}(1),coor_cells{3}(2),'r+');
plot(coor_cells{4}(1),coor_cells{4}(2),'r+');
plot(coor_cells{5}(1),coor_cells{5}(2),'r+');
plot(coor_cells{6}(1),coor_cells{6}(2),'r+');
plot(coor_cells{7}(1),coor_cells{7}(2),'r+');
for ii=1:L
     coor_users{ii}=[coor_cells{ii}(1)*ones(numOfUEs,1) coor_cells{ii}(2)*ones(numOfUEs,1)]+[user_distance{ii}.*cos(AoA{ii}) user_distance{ii}.*sin(AoA{ii})];

	circle(coor_cells{ii}(1),coor_cells{ii}(2),1);

    plot(coor_users{ii}(:,1),coor_users{ii}(:,2),'b*');
	hold on
end
hold on


figure
for index_kappa=1:length(kappa_tab)
     kappa{ii}=kappa_tab(index_kappa)*ones(numOfUEs,1)
for index_tab=1:length(numOfAnt_tab)
numOfAnt=numOfAnt_tab(index_tab); % Number of antennas in the base station
lambda=rho_lin*numOfAnt/numOfUEs;
%lambda=rho_lin;

%numOfAnt*rho_lin/numOfUEs;
%lambda=1;
%%%%% Generation positions des utilisateurs loi uniforme %%%%%%%%%

 ULA = (0:numOfAnt-1)'*pi;

for ii=1:L

   % user_distance{ii} = sqrt((R_max^2-R_min^2)*rand(numOfUEs,1)+R_min^2);
    %%% rician factor %%%%%%%%%%%
   % kappa{ii}=2*ones(numOfUEs,1);
    %AoA{ii} = -pi + 2*pi*rand(numOfUEs,1);
       %%% Computation of the distance between the generated users and all the other cells
    %%%% Compute the pathloss between each cell and all other users.
    %%%% distance{ii}(:,jj) compute the distance between UEs in cell ii and cell jj
    somme_pathloss{ii}=0;
    for jj=1:L
      distance{ii}(:,jj)= sqrt(sum([ coor_users{ii}-ones(numOfUEs,1)*[coor_cells{jj}(1),coor_cells{jj}(2)]].^2,2));
      pathloss{ii}(:,jj)= 1./(distance{ii}(:,jj).^beta_loss);
         if (ii==jj)
          pathloss{ii}(:,jj)=pathloss{ii}(:,jj)./(1+kappa{ii});
          A{ii}=exp(-1i*ULA*sin(AoA{ii}'));
    H_bar{ii}=(ones(numOfAnt,1)*(sqrt(pathloss{ii}(:,ii).*kappa{ii}))').*A{ii};
   % H_bar{ii}=zeros(numOfAnt,numOfUEs);
      end
somme_pathloss{ii}=somme_pathloss{ii}+ pathloss{ii}(:,jj);
    end
    for jj=1:L
    Phi{ii}(:,jj)=pathloss{ii}(:,ii).*pathloss{ii}(:,jj)./(1/rho_training_lin+somme_pathloss{ii});
end


end


[snr_signal_cell_RZF_th,snr_signal_cell_MRT_th]= results_mrt_rzf_th(H_bar,Phi,pathloss,somme_pathloss,lambda,Power,rho_training_lin,rho_lin);
for ii=1:L
snr_signal_cell_MRT_th_tab(index_tab,ii)=mean(snr_signal_cell_MRT_th{ii});
snr_signal_cell_RZF_th_tab(index_tab,ii)=mean(snr_signal_cell_RZF_th{ii});
end

end
plot(numOfAnt_tab,(mean(log2(real(snr_signal_cell_RZF_th_tab)+1),2)),'b*-');
hold on
plot(numOfAnt_tab,(mean(log2(1+real(snr_signal_cell_MRT_th_tab)),2)),'r*-');

end
