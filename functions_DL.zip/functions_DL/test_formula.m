L=3;
alpha=0.5;
rho_tr=10;
rho_tr_lin=10^(rho_tr/10);
kappa=3;
L_bar=alpha*(L-1)+1/(1+kappa);
nu=rho_tr/(1+rho_tr*L_bar);


phi=nu/(1+kappa)^2;
K=10;
N=100;

H_bar=orth(randn(N,K)+1i*randn(N,K))*sqrt(kappa/(kappa+1));
lambda=0.3;
D_tilde=phi*eye(K);
[delta_tilde,delta,T,T_tilde,Psi,Psi_tilde]=deterministic_matrix(H_bar,D_tilde,lambda);
polynomial_for_solving=[lambda 2*lambda+phi*(1-K/N) lambda+phi*(1-K/N)-phi*K/N+kappa/(1+kappa) -phi*K/N];

F=1/N*trace(H_bar'*T^2*H_bar*inv(eye(K)+delta*D_tilde)^2*D_tilde)
kappa*phi/((1+kappa)*(1+delta_tilde)^2)*(1/N)*trace(T_tilde^2)
1/N*trace(T^2)

(delta-kappa*(1+delta*phi)/((1+kappa)*(1+delta_tilde)^2)*(1/N*trace(T_tilde^2)))/(lambda*(1+delta_tilde))
gamma=1/N*trace(T^2);
gamma_tilde=phi^2/N*trace(T_tilde^2);
Delta=(1-F)^2-lambda^2*gamma*gamma_tilde;
nu=1/(Delta)*(1/N)*trace(T^2);
Psi=(K/N)/(delta-lambda*nu)
1/(lambda^2*gamma/Delta*(1/K*phi*trace(T_tilde^2)) +(1-F)/(Delta*(1+delta_tilde)^2)*(1/K)*trace(T_tilde*H_bar'*H_bar*T_tilde))
phi*K/N*((-1+(1-F)/Delta))^(-1)
N/K*lambda^2*gamma*gamma_tilde/(phi*Delta) + (1-F)*(F-1)*N/(Delta*K*phi)+(1-F)*N/(Delta*K*phi)

