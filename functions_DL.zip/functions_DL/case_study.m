%%%%  %%%
N = 50;
K=10;

% SNR for training phase
rho_tr = 10^(6/10);
% parameter rho
rho = 10^(10/10);
L_bar = alpha*(L-1) + 1/(1+kappa);
nu = rho_tr/(1 + rho_tr*L_bar);

A = sqrt(N)*randU(N);
mean_H_jj = sqrt(kappa/( 1 + kappa))*A(:,1:K);
% channel of the cell of interest
H_jj = mean_H_jj+ sqrt(1/( 1 + kappa))*sqrt(1/2)*(randn(N, K) + 1i*randn(N, K));

% channel of the interfering cells
H_jl = sqrt(alpha)*sqrt(1/2)*(randn(N, K, L - 1) + 1i*randn(N, K, L - 1));
% received signal
Y_j = H_jj + sum(H_jl,3) + sqrt(1/(2*rho_tr))*(randn(N, K) + 1i*randn(N, K));           
% compute channel estimates for UEs in cell j
hat_H_jj = mean_H_jj  + nu/(1 + kappa)*(Y_j  - mean_H_jj);
% compute channel estimates for UEs in cell j
hat_H_jl = nu*alpha*(Y_j  - mean_H_jj);

hat_h_jjk = hat_H_jj(:,1);
%v_jjk = (hat_H_jj*hat_H_jj' + (xi_j + 1/rho)*(eye(N)))\hat_h_jjk;

%% Generating unitary matrix

