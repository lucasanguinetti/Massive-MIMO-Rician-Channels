clear all
close all

numOfUEs=16;
numOfAnt=200;
define
%numOfUEs=80; % Number of users per cell
%numOfAnt=160; % Number of antennas in the base station

%L=6; % Cells number
%rho_training=20;
%rho_training_lin=10^(rho_training/10);
%rho = 5;  % SNR
%Power=1;
%rho_lin=10^(-rho/10);
%
%noise_lin=Power*rho_lin; % noise variance lineaire
%%%lambda=numOfAnt*rho_lin/numOfUEs;
%%lambda=1;
coor0=[0,0];
coor1=2*[cos(pi/6) sin(pi/6)];
coor2=2*[cos(pi/6) -sin(pi/6)];
coor3=2*[0,-1];
coor4=2*[-cos(pi/6),-sin(pi/6)];
coor5=2*[-cos(pi/6) sin(pi/6)];
coor6=[0,2];
%%coor0=[0 0]; % Coordinate of the center of the first cell
%%coor1=[sqrt(3)/2 1]; % Coordinate of the center of the fourth cell
%%coor2=[sqrt(3)/2 -1]; % Coordinate of the center of the fifth cell
%
coor_cells={coor0,coor1,coor2,coor3,coor4,coor5,coor6}


plot(coor_cells{1}(1),coor_cells{1}(2),'r+');
hold on
plot(coor_cells{2}(1),coor_cells{2}(2),'r+');
plot(coor_cells{3}(1),coor_cells{3}(2),'r+');
plot(coor_cells{4}(1),coor_cells{4}(2),'r+');
plot(coor_cells{5}(1),coor_cells{5}(2),'r+');
plot(coor_cells{6}(1),coor_cells{6}(2),'r+');
plot(coor_cells{7}(1),coor_cells{7}(2),'r+');
for ii=1:L
    circle(coor_cells{ii}(1),coor_cells{ii}(2),1);
    hold on
end
%hold on
%%
%%%%%%% Generation positions des utilisateurs loi uniforme %%%%%%%%%
%%
%Radius_cell=1;
%beta_loss=3;
%R_min=3/10*Radius_cell;
%R_max=9/10*Radius_cell;
ULA = (0:numOfAnt-1)'*pi;

for ii=1:L
    
    user_distance{ii} = sqrt((R_max^2-R_min^2)*rand(numOfUEs,1)+R_min^2);
    %%% rician factor %%%%%%%%%%%
    kappa{ii}=2*ones(numOfUEs,1);
    AoA{ii} = -pi + 2*pi*rand(numOfUEs,1);
    coor_users{ii}=[coor_cells{ii}(1)*ones(numOfUEs,1) coor_cells{ii}(2)*ones(numOfUEs,1)]+[user_distance{ii}.*cos(AoA{ii}) user_distance{ii}.*sin(AoA{ii})];
    %%% Computation of the distance between the generated users and all the other cells
    %%%% Compute the pathloss between each cell and all other users.
    %%%% distance{ii}(:,jj) compute the distance between UEs in cell ii and cell jj
    somme_pathloss{ii}=0;
    for jj=1:L
        distance{ii}(:,jj)= sqrt(sum([ coor_users{ii}-ones(numOfUEs,1)*[coor_cells{jj}(1),coor_cells{jj}(2)]].^2,2));
        pathloss{ii}(:,jj)= 1./(distance{ii}(:,jj).^beta_loss);
        if (ii==jj)
            pathloss{ii}(:,jj)=pathloss{ii}(:,jj)./(1+kappa{ii});
            A{ii}=exp(-1i*ULA*sin(AoA{ii}'));
            H_bar{ii}=(ones(numOfAnt,1)*(sqrt(pathloss{ii}(:,ii).*kappa{ii}))').*A{ii};
            % H_bar{ii}=zeros(numOfAnt,numOfUEs);
        end
        somme_pathloss{ii}=somme_pathloss{ii}+ pathloss{ii}(:,jj);
    end
    for jj=1:L
        Phi{ii}(:,jj)=pathloss{ii}(:,ii).*pathloss{ii}(:,jj)./(1/rho_training_lin+somme_pathloss{ii});
    end
    
    plot(coor_users{ii}(:,1),coor_users{ii}(:,2),'b*');
    
    
end

num_iter=1000;

for ii=1:L
    Cov{ii}=zeros(numOfAnt,numOfAnt);
    meanH{ii}=zeros(numOfAnt,numOfUEs);
    energy_signal_cell_moy{ii}=0;
    pilot_contamination_moy{ii}=0;
    intra_cell_inter_cell_interference_moy{ii}=0;
    intra_cell_interference_moy{ii}=0;
end

for iter=1:num_iter
    
    for ii=1:L
        
        Ytr{ii}=zeros(numOfAnt,numOfUEs);
        for jj=1:L
            H{ii,jj}=((randn(numOfAnt,numOfUEs)+1i*randn(numOfAnt,numOfUEs))/sqrt(2))*diag(sqrt(pathloss{ii}(:,jj)));
            if (ii==jj)
                H{ii,ii}=H{ii,ii}+H_bar{ii};
            end
            Ytr{ii}=Ytr{ii}+H{ii,jj};
        end
        Ytr{ii}=Ytr{ii}+1/sqrt(rho_training_lin)*(randn(numOfAnt,numOfUEs)+1i*randn(numOfAnt,numOfUEs))/sqrt(2);
        H_hat{ii}=H_bar{ii}+(Ytr{ii}-H_bar{ii})*diag((pathloss{ii}(:,ii)))./(1/rho_training_lin +ones(numOfAnt,1)*(somme_pathloss{ii})');
        W_l_MRT{ii}=H_hat{ii};
        %%%For checking %%%%
        beta(ii)=Power/(1/numOfUEs*trace(W_l_MRT{ii}*(W_l_MRT{ii})'));
        W_l_MRT{ii}=sqrt(beta(ii))*W_l_MRT{ii};
        Hcellonly{ii}=H{ii,ii};
    end
    for l=1:L
        pilot_contamination{l}=0;
        for lcomp=1:L
            if (lcomp~=l)
                pilot_contamination{l}=pilot_contamination{l}+abs(diag(H{lcomp,l}'*W_l_MRT{lcomp})).^2;
            end
        end
        energy_signal_cell=cellfun(@(x,y) (sum(conj(x).*y,1))',Hcellonly,W_l_MRT,'UniformOutput',false);
        energy_signal_cell=cellfun(@(x) abs(x).^2,energy_signal_cell,'UniformOutput',false);
        
        minus_energy_signal_cell= cellfun(@(x) -x, energy_signal_cell,'UniformOutput',false);
        
        pilot_contamination_moy{l}=pilot_contamination_moy{l}+pilot_contamination{l};
    end
    
    
    for ii=1:L
        energy_signal_cell_moy{ii} = energy_signal_cell_moy{ii}+energy_signal_cell{ii};
    end
    
    for l=1:L
        intra_cell_interference_MRT{l} = abs(diag((H{l,l})'*W_l_MRT{l}*(W_l_MRT{l})'*H{l,l}))-diag((H{l,l})'*W_l_MRT{l}).^2;
        intra_cell_interference_moy{l}=intra_cell_interference_moy{l}+ intra_cell_interference_MRT{l};
    end
    
    for l=1:L
        intra_cell_inter_cell_interference{l}=0;
        for lcomp=1:L
            intra_cell_inter_cell_interference{l}= intra_cell_inter_cell_interference{l} +diag((H{lcomp,l})'*W_l_MRT{lcomp}*(W_l_MRT{lcomp})'*H{lcomp,l})-abs(diag(H{lcomp,l}'*W_l_MRT{lcomp})).^2;
        end
        intra_cell_inter_cell_interference_moy{l}=intra_cell_inter_cell_interference_moy{l}+intra_cell_inter_cell_interference{l};
    end
end

energy_signal_cell_moy=cellfun(@(x) x./(num_iter*numOfAnt),energy_signal_cell_moy,'UniformOutput',false);
pilot_contamination_moy=cellfun(@(x) x./(num_iter*numOfAnt),pilot_contamination_moy,'UniformOutput',false);
intra_cell_inter_cell_interference_moy=cellfun(@(x) x./(num_iter*numOfAnt),intra_cell_inter_cell_interference_moy,'UniformOutput',false);
intra_cell_interference_moy=cellfun(@(x) x./(num_iter*numOfAnt),intra_cell_interference_moy,'UniformOutput',false);
for ii=1:L
    total_interference{ii}=intra_cell_inter_cell_interference_moy{ii} + pilot_contamination_moy{ii};
end
snr_signal_cell_moy=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_moy,total_interference,'UniformOutput',false);

for ii=1:L
    Theta_bar(ii)=1/(1/numOfUEs*(sum(Phi{ii}(:,ii)) + 1/numOfAnt * trace((H_bar{ii})'*H_bar{ii})));
end

for l=1:L
    energy_signal_cell_MRT_th{l}=Theta_bar(l)*(Phi{l}(:,l)+1/numOfAnt*diag((H_bar{l})'*H_bar{l})).^2;
    pilot_contamination_MRT_th{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            pilot_contamination_MRT_th{l}=pilot_contamination_MRT_th{l}+Theta_bar(lcomp)*Phi{lcomp}(:,l).^2 +1/numOfAnt * Theta_bar(lcomp)*pathloss{lcomp}(:,l).*(Phi{lcomp}(:,lcomp)+1/numOfAnt*diag((H_bar{lcomp})'*H_bar{lcomp}));
        end
    end
end

for l=1:L
    first_term_interference_MRT{l}=0;
    for lcomp=1:L
        first_term_interference_MRT{l}=first_term_interference_MRT{l} + Theta_bar(lcomp)/numOfAnt*(pathloss{lcomp}(:,l)).*(sum(Phi{lcomp}(:,lcomp))-Phi{lcomp}(:,lcomp) + 1/numOfAnt*trace((H_bar{lcomp})'*H_bar{lcomp})-1/numOfAnt*diag((H_bar{lcomp})'*H_bar{lcomp}));
    end
end

%for l=1:L
%    for k=1:numOfUEs
%    first_term_interference_test_MRT{l}(k)=0;
%    for lcomp=1:L
%        for ii=1:numOfUEs
%            first_term_interference_test_MRT{l}(k)=first_term_interference_test_MRT{l}(k)+1/numOfAnt*Theta_bar(lcomp)*pathloss{lcomp}(k,l)*((Phi{lcomp}(ii,lcomp))+1/numOfAnt*(H_bar{lcomp}(:,ii))'*H_bar{lcomp}(:,ii));
%end
%end
%end
%end

for l=1:L
    second_interference_MRT{l}= 1/(numOfAnt^2)*Theta_bar(l)*(sum(Phi{l}(:,l))*diag((H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).*Phi{l}(:,l)+diag((H_bar{l})'*H_bar{l}*(H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).^2);
end

for l=1:L
    intra_interference_th{l}= 1/(numOfAnt^2)*Theta_bar(l)*(sum(Phi{l}(:,l))*diag((H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).*Phi{l}(:,l)+diag((H_bar{l})'*H_bar{l}*(H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).^2) +Theta_bar(l)/numOfAnt*(pathloss{l}(:,l)).*(sum(Phi{l}(:,l))-Phi{l}(:,l) + 1/numOfAnt*trace((H_bar{l})'*H_bar{l})-1/numOfAnt*diag((H_bar{l})'*H_bar{l})) ;
    first_term_interference_th_test{l}=  1/(numOfAnt^2)*Theta_bar(l)*(sum(Phi{l}(:,l))*diag((H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).*Phi{l}(:,l));
    second_term_interference_th_test{l}=(diag((H_bar{l})'*H_bar{l}*(H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).^2)*Theta_bar(l)/(numOfAnt^2);
end
for l=1:L
    intra_interference_test_th{l}=zeros(numOfUEs,1);
    first_term_intra_interference_th{l}=zeros(numOfUEs,1);
    second_term_intra_interference_th{l}=zeros(numOfUEs,1);
    for k=1:numOfUEs
        for ii=1:numOfUEs
            if (ii~=k)
                intra_interference_test_th{l}(k)= intra_interference_test_th{l}(k) + 1/numOfAnt * Theta_bar(l)*(pathloss{l}(k,l)*(Phi{l}(ii,l)+1/numOfAnt*(H_bar{l}(:,ii))'*H_bar{l}(:,ii))+1/numOfAnt*Phi{l}(ii,l)*(H_bar{l}(:,k))'*H_bar{l}(:,k)+1/numOfAnt*abs(H_bar{l}(:,ii)'*H_bar{l}(:,k))^2);
                first_term_intra_interference_th{l}(k)=first_term_intra_interference_th{l}(k)+(1/(numOfAnt^2))*Theta_bar(l)*Phi{l}(ii,l)*(H_bar{l}(:,k))'*H_bar{l}(:,k);
                second_term_intra_interference_th{l}(k)= second_term_intra_interference_th{l}(k) + (1/(numOfAnt^2))*Theta_bar(l)*abs((H_bar{l}(:,k))'*H_bar{l}(:,ii))^2;
            end
        end
    end
end
%
%for l=1:L
%    for k=1:numOfUEs
%        second_interference_test_MRT{l}(k)=0;
%        for ii=1:numOfUEs
%            if (k~=ii)
%                 second_interference_test_MRT{l}(k)= second_interference_test_MRT{l}(k) +Theta_bar(l)/(numOfAnt^2)*(Phi{l}(ii,l)*(H_bar{l}(:,k))'*H_bar{l}(:,k)+abs((H_bar{l}(:,ii))'*H_bar{l}(:,k))^2);
%            end
%        end
%    end
%end


for l=1:L
    interference_MRT_th{l}= first_term_interference_MRT{l} + second_interference_MRT{l};
    total_interference_MRT_th{l}= interference_MRT_th{l} + pilot_contamination_MRT_th{l};
end


for ii=1:L
    total_interference_MRT{ii}=intra_cell_inter_cell_interference_moy{ii} + pilot_contamination_moy{ii};
end
snr_signal_cell_MRT_moy=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_moy,total_interference_MRT,'UniformOutput',false);

snr_signal_cell_MRT_th=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_MRT_th,total_interference_MRT_th,'UniformOutput',false);


