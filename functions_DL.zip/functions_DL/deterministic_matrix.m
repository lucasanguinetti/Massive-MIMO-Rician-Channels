function [delta_tilde,delta,T,T_tilde,Psi,Psi_tilde]=deterministic_matrix(A,D_tilde,rho)
[N,n]=size(A);
Psi=1/rho*eye(N);
Psi_tilde=1/rho*eye(n);
Psi_prev=zeros(N,N);
Psi_tilde_prev=zeros(n,n);

T=inv(rho*eye(N,N)+A*A');
T_tilde=inv(rho*eye(n,n)+A'*A);
T_prev=zeros(N,N);
T_tilde_prev=zeros(n,n);
delta=(1/N)*trace(T);
delta_tilde=(1/N)*trace(D_tilde*T_tilde);

iter=0;
delta_prev=0;
delta_tilde_prev=0;
while((abs((delta_prev-delta)/delta_prev) >1e-15)    && (iter <100000))
	iter=iter+1;
	delta_prev=delta;
	delta_tilde_prev=delta_tilde;
	delta=(1/(N))*trace(inv(rho*(1+delta_tilde_prev)*eye(N)+A*inv(eye(n)+delta_prev*D_tilde)*A'));
	delta_tilde=(1/(N))*trace(D_tilde*inv(rho*(eye(n)+delta_prev*D_tilde)+A'*A/(1+delta_tilde_prev)));
	%error_prev(iter)=abs(delta_prev-delta);
end
%	Psi= 1/(rho*(1+delta_tilde)) *eye(N);
%	Psi_tilde=((1/rho)*inv(eye(n)+delta*D_tilde));
%	T=inv(inv(Psi)+rho*A*Psi_tilde*A');
%	T_tilde=inv(inv(Psi_tilde)+rho*A'*Psi*A);
T=inv(rho*(1+delta_tilde)*eye(N)+A*diag(1./(1+delta*diag(D_tilde)))*A');
T_tilde=inv(rho*(eye(n)+delta*D_tilde)+A'*A/(1+delta_tilde));


