clear all
close all
define
%kappa_tab=[3];
kappa_rice=3;
coor0=[0,0];
coor1=2*[cos(pi/6) sin(pi/6)];
coor2=2*[cos(pi/6) -sin(pi/6)];
coor3=2*[0,-1];
coor4=2*[-cos(pi/6),-sin(pi/6)];
coor5=2*[-cos(pi/6) sin(pi/6)];
coor6=[0,2];
%coor0=[0 0]; % Coordinate of the center of the first cell
%coor1=[sqrt(3)/2 1]; % Coordinate of the center of the fourth cell
%coor2=[sqrt(3)/2 -1]; % Coordinate of the center of the fifth cell

coor_cells={coor0,coor1,coor2,coor3,coor4,coor5,coor6}


plot(coor_cells{1}(1),coor_cells{1}(2),'r+');
hold on
plot(coor_cells{2}(1),coor_cells{2}(2),'r+');
plot(coor_cells{3}(1),coor_cells{3}(2),'r+');
plot(coor_cells{4}(1),coor_cells{4}(2),'r+');
plot(coor_cells{5}(1),coor_cells{5}(2),'r+');
plot(coor_cells{6}(1),coor_cells{6}(2),'r+');
plot(coor_cells{7}(1),coor_cells{7}(2),'r+');
figure
for ii=1:L
     coor_users{ii}=[coor_cells{ii}(1)*ones(numOfUEs,1) coor_cells{ii}(2)*ones(numOfUEs,1)]+[user_distance{ii}.*cos(AoA{ii}) user_distance{ii}.*sin(AoA{ii})];

	circle(coor_cells{ii}(1),coor_cells{ii}(2),1);

    hold on
    plot(coor_users{ii}(:,1),coor_users{ii}(:,2),'b*');
end


numOfAnt=20;
%for index_kappa=1:length(kappa_tab)
 %    kappa{ii}=kappa_tab(index_kappa)*ones(numOfUEs,1)
%for index_tab=1:length(numOfAnt_tab)
%numOfAnt=numOfAnt_tab_rice(index_tab); % Number of antennas in the base station
lambda=rho_lin*numOfAnt/numOfUEs;
%lambda=rho_lin;

%numOfAnt*rho_lin/numOfUEs;
%lambda=1;
%%%%% Generation positions des utilisateurs loi uniforme %%%%%%%%%

 ULA = (0:numOfAnt-1)'*pi;

for ii=1:L

   % user_distance{ii} = sqrt((R_max^2-R_min^2)*rand(numOfUEs,1)+R_min^2);
    %%% rician factor %%%%%%%%%%%
    kappa{ii}=kappa_rice*ones(numOfUEs,1);
    %AoA{ii} = -pi + 2*pi*rand(numOfUEs,1);
       %%% Computation of the distance between the generated users and all the other cells
    %%%% Compute the pathloss between each cell and all other users.
    %%%% distance{ii}(:,jj) compute the distance between UEs in cell ii and cell jj
    somme_pathloss{ii}=zeros(numOfUEs,1);
    for jj=1:L
      distance{ii}(:,jj)= sqrt(sum([ coor_users{ii}-ones(numOfUEs,1)*[coor_cells{jj}(1),coor_cells{jj}(2)]].^2,2));
      pathloss{ii}(:,jj)= 1./(distance{ii}(:,jj).^beta_loss);
         if (ii==jj)
          pathloss{ii}(:,jj)=pathloss{ii}(:,jj)./(1+kappa{ii});
          A{ii}=exp(-1i*ULA*sin(AoA{ii}'));
    H_bar{ii}=(ones(numOfAnt,1)*(sqrt(pathloss{ii}(:,ii).*kappa{ii}))').*A{ii};
   % H_bar{ii}=zeros(numOfAnt,numOfUEs);
          end
    somme_pathloss{ii}=somme_pathloss{ii}+ pathloss{ii}(:,jj);
    end
    for jj=1:L
    Phi{ii}(:,jj)=pathloss{ii}(:,ii).*pathloss{ii}(:,jj)./(1/rho_training_lin+somme_pathloss{ii});
end
end
delta_tilde_tot=zeros(L,1);
delta_tot=zeros(L,1);
gamma_d_tab=zeros(L,1);
gamma_tilde_d_tab=zeros(L,1);
F=zeros(L,1);
Delta=zeros(L,1);
%ubar=zeros(numOfUEs,L);


for ii=1:L
[delta_tilde,delta,T,T_tilde,Psi,Psi_tilde]=deterministic_matrix(H_bar{ii}/sqrt(numOfAnt),diag(Phi{ii}(:,ii)),lambda);

delta_tilde_tot(ii)=delta_tilde;
delta_tot(ii)=delta;
T_tab{ii}=T;
T_tilde_tab{ii}=T_tilde;
gamma_d_tab(ii)=1/numOfAnt*trace(T^2);
D_tilde=diag(Phi{ii}(:,ii));
gamma_tilde_d_tab(ii)=1/numOfAnt*trace(diag(Phi{ii}(:,ii))*T_tilde*diag(Phi{ii}(:,ii))*T_tilde);
F(ii)=(1/(numOfAnt^2))*trace(T^2*H_bar{ii}*diag((Phi{ii}(:,ii))./((1+delta*Phi{ii}(:,ii)).^2))*H_bar{ii}');
F1(ii)=(1/(numOfAnt^2))*trace(T^2*H_bar{ii}*D_tilde*inv(eye(numOfUEs)+delta*D_tilde)^2*H_bar{ii}');
Delta(ii)=(1-F(ii))^2-lambda^2*gamma_d_tab(ii)*gamma_tilde_d_tab(ii);
nu_d(ii)=(1/Delta(ii))*(1/numOfAnt)*trace(T^2);
Psi_bar(ii)=(numOfUEs/numOfAnt) /(delta-lambda*nu_d(ii)); %%%% Equivalent deterministe of betaii/N ***********
%%%Checking DONE **********

Psi_bar_test(ii)=1/(lambda^2*gamma_d_tab(ii)/Delta(ii)*(1/numOfUEs*sum(Phi{ii}(:,ii).*diag(T_tilde^2))) +(1-F(ii))/Delta(ii)*(1/numOfUEs)*sum(diag(H_bar{ii}'*T^2*H_bar{ii}/numOfAnt).*(1./(1+delta*Phi{ii}(:,ii))).^2));
Psi_bar_test_bis(ii)=1/(lambda^2*gamma_d_tab(ii)/Delta(ii)*(1/numOfUEs*sum(Phi{ii}(:,ii).*diag(T_tilde^2))) +(1-F(ii))/(Delta(ii)*(1+delta_tilde)^2)*(1/numOfUEs)*(1/numOfAnt)*trace(T_tilde*H_bar{ii}'*H_bar{ii}*T_tilde));

%%%% Slow implementation
%for k=1:numOfUEs
 %   ubar(k,ii)= delta_tot(ii)*Phi{ii}(k,ii) + 1/(lambda * T_tilde(k,k)) * (H_bar{ii}(:,k))'*T*H_bar{ii}(:,k) /(numOfAnt*(1+delta*Phi{ii}(k,ii)));
%end

%%%% Fast implementation 
ubar{ii}= delta_tot(ii) * Phi{ii}(:,ii) + (diag(H_bar{ii}'*T*H_bar{ii}).*(1./(lambda*diag(T_tilde))))./(numOfAnt*(1+delta*Phi{ii}(:,ii)));

ubar_test_formula{ii} = 1./(lambda*diag(T_tilde)) -1;

omega{ii}=delta_tot(ii) * pathloss{ii}(:,ii) + diag(H_bar{ii}'*T*H_bar{ii}).*(1./(lambda*diag(T_tilde)))./(numOfAnt*(1+delta*Phi{ii}(:,ii)));


energy_signal_cell_th{ii}=Psi_bar(ii)*ubar{ii}.^2./((1+ubar{ii}).^2); %%%% Checking of the signal term %%%%%**********Checking DONE **********

end

for l=1:L

zeta(:,l)= (1-F(l))/Delta(l) * (diag(H_bar{l}'*T_tab{l}^2*H_bar{l}).*(1./(lambda*diag(T_tilde_tab{l})).^2))./(numOfAnt*(1+delta_tot(l)*Phi{l}(:,l)).^2);
zeta_newformula(:,l)= (1-F(l))/(Delta(l)*numOfAnt)*diag(T_tilde_tab{l}*(H_bar{l})'*H_bar{l}*T_tilde_tab{l})./(lambda^2*diag(T_tilde_tab{l}).^2*(1+delta_tilde_tot(l))^2);

zeta_newformula(:,l)= zeta_newformula(:,l) +gamma_d_tab(l)/Delta(l)* (diag(T_tilde_tab{l}*diag(Phi{l}(:,l))*T_tilde_tab{l})./(diag(T_tilde_tab{l}).^2)-Phi{l}(:,l));
for k=1:numOfUEs
  %  somme(k,l)=0;
    for ii=1:numOfUEs
 %       somme(k,l)=somme(k,l)+Phi{l}(ii,l)/(1+Phi{l}(ii,l)*delta_tot(l))^2 *(1/(numOfAnt^2)) * (H_bar{l}(:,k))'*T_tab{l}*H_bar{l}(:,ii)*(H_bar{l}(:,ii))'*T_tab{l}*H_bar{l}(:,k)/(lambda^2*(T_tilde_tab{l}(k,k))^2*(1+delta_tot(l)*Phi{l}(k,l))^2);
        if (ii~=k)
            zeta(k,l) =zeta(k,l) + gamma_d_tab(l)/Delta(l)*Phi{l}(ii,l)/(1+Phi{l}(ii,l)*delta_tot(l))^2 *(1/(numOfAnt^2)) * (H_bar{l}(:,k))'*T_tab{l}*H_bar{l}(:,ii)*(H_bar{l}(:,ii))'*T_tab{l}*H_bar{l}(:,k)/(lambda^2*(T_tilde_tab{l}(k,k))^2*(1+delta_tot(l)*Phi{l}(k,l))^2);
            %zeta_newformula(k,l)=  zeta_newformula(k,l) + gamma_d_tab(l)/Delta(l)*Phi{l}(ii,l)/(1+Phi{l}(ii,l)*delta_tot(l))^2 *(1/(numOfAnt^2)) * (H_bar{l}(:,k))'*T_tab{l}*H_bar{l}(:,ii)*(H_bar{l}(:,ii))'*T_tab{l}*H_bar{l}(:,k)/(lambda^2*(T_tilde_tab{l}(k,k))^2*(1+delta_tot(l)*Phi{l}(k,l))^2);
        end
end
%somme_bis(k,l)= (1/(numOfAnt^2)) * (H_bar{l}(:,k))'*T_tab{l}*H_bar{l}*diag(Phi{l}(:,l))*inv(eye(numOfUEs)+delta_tot(l)*diag(Phi{l}(:,l)))^2*(H_bar{l})'*T_tab{l}*H_bar{l}(:,k)/(lambda^2*T_tilde_tab{l}(k,k)^2*(1+delta_tot(l)*Phi{l}(k,l))^2);
%A=((1/lambda*inv(eye(numOfUEs)+delta_tot(l)*diag(Phi{l}(:,l))))-T_tilde_tab{l})*diag(Phi{l}(:,l))*((1/lambda*inv(eye(numOfUEs)+delta_tot(l)*diag(Phi{l}(:,l))))-T_tilde_tab{l});
%somme_bisbis(k,l)=A(k,k)/(T_tilde_tab{l}(k,k)^2);
end
%somme_test(:,l)=1/lambda^2*Phi{l}(:,l)./((1+delta_tot(l)*Phi{l}(:,l)).^2.*diag(T_tilde_tab{l}).^2)-2/lambda*Phi{l}(:,l)./((1+delta_tot(l)*Phi{l}(:,l)).*diag(T_tilde_tab{l})) +Phi{l}(:,l).*diag(T_tilde_tab{l}^2)./(diag(T_tilde_tab{l}).^2);

end
 %%%%%%%%% Checking of pilot contamination: Some difference due to the fact that the values are small, but I think results are correct  %%%%%%%%%%%
for l=1:L
    pilot_contamination_th{l}=0;
    for lcomp=1:L
         if (lcomp~=l)
        pilot_contamination_th{l} = pilot_contamination_th{l} + Psi_bar(lcomp)*delta_tot(lcomp)^2*Phi{lcomp}(:,l).^2./((1+ubar{lcomp}).^2);
        end
    end
end


%%%%% Checking first term interference  %%%%%%%%%%%%%% %%%%%%%%%%%%% First term checked: Good results %%%%%%%%%%%%%%
for l=1:L
first_term_inter_intra_interference{l}=0;
first_term_inter_intra_interference_new_notation{l}=0;
first_term_inter_intra_interference_new_formula{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            csi= pathloss{lcomp}(:,l)*delta_tot(lcomp) - (Phi{lcomp}(:,l)*delta_tot(lcomp)).^2./(1+ubar{lcomp});
            csi_new_formula=  pathloss{lcomp}(:,l)*delta_tot(lcomp) - lambda * diag(T_tilde_tab{lcomp}).*(Phi{lcomp}(:,l)*delta_tot(lcomp)).^2;
            first_term_inter_intra_interference{l}= first_term_inter_intra_interference{l} + Psi_bar(lcomp)*(pathloss{lcomp}(:,l)*delta_tot(lcomp)-delta_tot(lcomp)^2*Phi{lcomp}(:,l).^2./((1+ubar{lcomp})));
            first_term_inter_intra_interference_new_notation{l}= first_term_inter_intra_interference_new_notation{l}+Psi_bar(lcomp) *csi;
            first_term_inter_intra_interference_new_formula{l}=first_term_inter_intra_interference_new_formula{l} +Psi_bar(lcomp)*csi_new_formula;
        else
            csi = pathloss{l}(:,l) * delta_tot(l) +(1/numOfAnt) *diag((H_bar{l})'*T_tab{l}*H_bar{l})./(lambda*diag(T_tilde_tab{l}).*(1+delta_tot(l).*Phi{l}(:,l))) -ubar{l}.^2./(1+ubar{l});
            csi_new_formula = (pathloss{l}(:,l)-Phi{l}(:,l))*delta_tot(l)+1-lambda*diag(T_tilde_tab{l});
            % pathloss{l}(:,l) * delta_tot(l) -1./((lambda*diag(T_tilde_tab{l})).^3) +2./((lambda*diag(T_tilde_tab{l})).^2) -1;
            first_term_inter_intra_interference{l}= first_term_inter_intra_interference{l}+ Psi_bar(l)*(omega{l}-ubar{l}.^2./(1+ubar{l}));
first_term_inter_intra_interference_new_notation{l}=first_term_inter_intra_interference_new_notation{l}+csi*Psi_bar(l);
first_term_inter_intra_interference_new_formula{l}=first_term_inter_intra_interference_new_formula{l}+csi*Psi_bar(l);

        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for l=1:L
second_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            second_term_inter_intra_interference{l} = second_term_inter_intra_interference{l} +  Psi_bar(lcomp) * (Phi{lcomp}(:,l)*delta_tot(lcomp)./(1+ubar{lcomp})).^2;
    else
         second_term_inter_intra_interference{l}=  second_term_inter_intra_interference{l} +  Psi_bar(lcomp)*(ubar{lcomp}./(1+ubar{lcomp})).^2;
     end
 end
end

for l=1:L
third_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            mu=pathloss{lcomp}(:,l) * nu_d(lcomp) - Phi{lcomp}(:,l).^2.*delta_tot(lcomp).*(2*nu_d(lcomp)*(1+ubar{lcomp})-delta_tot(lcomp)*(Phi{lcomp}(:,lcomp)*nu_d(lcomp)+zeta(:,lcomp)))./((1+ubar{lcomp}).^2);
third_term_inter_intra_interference{l}= third_term_inter_intra_interference{l} + Psi_bar(lcomp) *mu;
    else
        mu=pathloss{l}(:,l)*nu_d(l)+zeta(:,l)- ubar{l}.*(Phi{l}(:,l)*nu_d(l)+zeta(:,l)) .* (2+ubar{l})./((1+ubar{l}).^2);
        third_term_inter_intra_interference{l}= third_term_inter_intra_interference{l}+ Psi_bar(l)*mu;
    end
    end

end

for ii=1:L
total_interference_th{ii}= first_term_inter_intra_interference{ii} - lambda* third_term_inter_intra_interference{ii}-second_term_inter_intra_interference{ii} +pilot_contamination_th{ii};
intra_cell_inter_cell_interference_th{ii} = first_term_inter_intra_interference{ii} - lambda* third_term_inter_intra_interference{ii} -second_term_inter_intra_interference{ii};

end
snr_signal_cell_RZF_th=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_th,total_interference_th,'UniformOutput',false);


%[snr_signal_cell_RZF_th,snr_signal_cell_MRT_th]= results_mrt_rzf_th(H_bar,Phi,pathloss,somme_pathloss,lambda,Power,rho_training_lin,rho_lin);


