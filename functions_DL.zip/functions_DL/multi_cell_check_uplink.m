clear all
close all

numOfUEs=100; % Number of users per cell
numOfAnt=320; % Number of antennas in the base station

L=6; % Cells number
rho_training=20;
rho_training_lin=10^(rho_training/10);
rho = 5;  % SNR
Power=1;
rho_lin=10^(-rho/10);

noise_lin=Power*rho_lin; % noise variance lineaire
%lambda=numOfAnt*rho_lin/numOfUEs;
lambda=1;
coor0=[0,0];
coor1=2*[cos(pi/6) sin(pi/6)];
coor2=2*[cos(pi/6) -sin(pi/6)];
coor3=2*[0,-1];
coor4=2*[-cos(pi/6),-sin(pi/6)];
coor5=2*[-cos(pi/6) sin(pi/6)];
coor6=[0,2];
%coor0=[0 0]; % Coordinate of the center of the first cell
%coor1=[sqrt(3)/2 1]; % Coordinate of the center of the fourth cell
%coor2=[sqrt(3)/2 -1]; % Coordinate of the center of the fifth cell

coor_cells={coor0,coor1,coor2,coor3,coor4,coor5,coor6}


plot(coor_cells{1}(1),coor_cells{1}(2),'r+');
hold on
plot(coor_cells{2}(1),coor_cells{2}(2),'r+');
plot(coor_cells{3}(1),coor_cells{3}(2),'r+');
plot(coor_cells{4}(1),coor_cells{4}(2),'r+');
plot(coor_cells{5}(1),coor_cells{5}(2),'r+');
plot(coor_cells{6}(1),coor_cells{6}(2),'r+');
plot(coor_cells{7}(1),coor_cells{7}(2),'r+');
for ii=1:L
	circle(coor_cells{ii}(1),coor_cells{ii}(2),1);
	hold on
end
hold on

%%%%% Generation positions des utilisateurs loi uniforme %%%%%%%%%

Radius_cell=1;
beta_loss=3;
R_min=9/10*Radius_cell;
R_max=8/10*Radius_cell;
 ULA = (0:numOfAnt-1)'*pi;

for ii=1:L

    user_distance{ii} = sqrt((R_max^2-R_min^2)*rand(numOfUEs,1)+R_min^2);
    %%% rician factor %%%%%%%%%%%
    kappa{ii}=2*ones(numOfUEs,1);
    AoA{ii} = -pi + 2*pi*rand(numOfUEs,1);
    coor_users{ii}=[coor_cells{ii}(1)*ones(numOfUEs,1) coor_cells{ii}(2)*ones(numOfUEs,1)]+[user_distance{ii}.*cos(AoA{ii}) user_distance{ii}.*sin(AoA{ii})];
    %%% Computation of the distance between the generated users and all the other cells
    %%%% Compute the pathloss between each cell and all other users.
    %%%% distance{ii}(:,jj) compute the distance between UEs in cell ii and cell jj
    somme_pathloss{ii}=0;
    for jj=1:L
      distance{ii}(:,jj)= sqrt(sum([ coor_users{ii}-ones(numOfUEs,1)*[coor_cells{jj}(1),coor_cells{jj}(2)]].^2,2));
      pathloss{ii}(:,jj)= 1./(distance{ii}(:,jj).^beta_loss);
         if (ii==jj)
          pathloss{ii}(:,jj)=pathloss{ii}(:,jj)./(1+kappa{ii});
          A{ii}=exp(-1i*ULA*sin(AoA{ii}'));
    H_bar{ii}=(ones(numOfAnt,1)*(sqrt(pathloss{ii}(:,ii).*kappa{ii}))').*A{ii};
   % H_bar{ii}=zeros(numOfAnt,numOfUEs);
      end
somme_pathloss{ii}=somme_pathloss{ii}+ pathloss{ii}(:,jj);
    end
    for jj=1:L
    Phi{ii}(:,jj)=pathloss{ii}(:,ii).*pathloss{ii}(:,jj)./(1/rho_training_lin+somme_pathloss{ii});
end

    plot(coor_users{ii}(:,1),coor_users{ii}(:,2),'b*');

    
end

num_iter=100;
%%%% Verification of the accuracy of the covariance phi DONE. %%%%%%%%%

for ii=1:L
Cov{ii}=zeros(numOfAnt,numOfAnt);
meanH{ii}=zeros(numOfAnt,numOfUEs);
energy_signal_cell_moy{ii}=0;
energy_signal_cell_MRC_moy{ii}=0;
pilot_contamination_moy{ii}=0;
intra_cell_inter_cell_interference_moy{ii}=0;
first_term_interference_emp_moy{ii}=0;
second_term_interference_emp_moy{ii}=0;
third_term_interference_emp_moy{ii}=0;
end

for iter=1:num_iter

for ii=1:L

    Ytr{ii}=zeros(numOfAnt,numOfUEs);
    for jj=1:L
 H{ii,jj}=((randn(numOfAnt,numOfUEs)+1i*randn(numOfAnt,numOfUEs))/sqrt(2))*diag(sqrt(pathloss{ii}(:,jj)));
      if (ii==jj)
        H{ii,ii}=H{ii,ii}+H_bar{ii};
      end
    Ytr{ii}=Ytr{ii}+H{ii,jj};
   end
   Ytr{ii}=Ytr{ii}+1/sqrt(rho_training_lin)*(randn(numOfAnt,numOfUEs)+1i*randn(numOfAnt,numOfUEs))/sqrt(2);
   H_hat{ii}=H_bar{ii}+(Ytr{ii}-H_bar{ii})*diag((pathloss{ii}(:,ii)))./(1/rho_training_lin +ones(numOfAnt,1)*(somme_pathloss{ii})');
   error_channel{ii}=H_hat{ii}-H{ii,ii};

tau(ii)=0;
   for l=1:L
        tau(ii)= tau(ii)+sum(pathloss{ii}(:,l))-sum(Phi{ii}(:,ii));
    end
    v_MMSE{ii}= inv(H_hat{ii}*(H_hat{ii})'+(tau(ii)+numOfAnt*lambda)*eye(numOfAnt))*H_hat{ii};
    v_MRC{ii}=H_hat{ii};
  % Cov{ii}=Cov{ii}+ (H_hat{ii}(:,4)-H_bar{ii}(:,4)) *(H_hat{ii}(:,4)-H_bar{ii}(:,4))';
 %  meanH{ii}=meanH{ii}+H_hat{ii};
   % Hcellonly{ii}=H{ii,ii};
end

energy_signal_cell=cellfun(@(x,y) (sum(conj(x).*y,1))',H_hat,v_MMSE,'UniformOutput',false);
energy_signal_cell=cellfun(@(x) abs(x).^2,energy_signal_cell,'UniformOutput',false);

energy_signal_cell_MRC=cellfun(@(x,y) (sum(conj(x).*y,1))',H_hat,v_MRC,'UniformOutput',false);
energy_signal_cell_MRC=cellfun(@(x) abs(x).^2,energy_signal_cell,'UniformOutput',false);
for ii=1:L
    energy_signal_cell_moy{ii} = energy_signal_cell_moy{ii}+energy_signal_cell{ii};
    energy_signal_cell_MRC_moy{ii} = energy_signal_cell_MRC_moy{ii}+energy_signal_cell_MRC{ii};
end

end


energy_signal_cell_moy=cellfun(@(x) x./(num_iter),energy_signal_cell_moy,'UniformOutput',false);
energy_signal_cell_MRC_moy=cellfun(@(x) x./(num_iter),energy_signal_cell_MRC_moy,'UniformOutput',false);
%%%%%% Equivalent deterministe: Checking of each term %%%%%%%%%%%%%%%%%%%

delta_tilde_tot=zeros(L,1);
delta_tot=zeros(L,1);
gamma_d_tab=zeros(L,1);
gamma_tilde_d_tab=zeros(L,1);
F=zeros(L,1);
Delta=zeros(L,1);
for ii=1:L
[delta_tilde,delta,T,T_tilde,Psi,Psi_tilde]=deterministic_matrix(H_bar{ii}/sqrt(numOfAnt),diag(Phi{ii}(:,ii)),lambda+tau(ii)/numOfAnt);

delta_tilde_tot(ii)=delta_tilde;
delta_tot(ii)=delta;
ubar{ii}= delta_tot(ii) * Phi{ii}(:,ii) + (diag(H_bar{ii}'*T*H_bar{ii}).*(1./(lambda*diag(T_tilde))))./(numOfAnt*(1+delta*Phi{ii}(:,ii)));
energy_signal_cell_th{ii} = ubar{ii}.^2./((1+ubar{ii}).^2);

end
