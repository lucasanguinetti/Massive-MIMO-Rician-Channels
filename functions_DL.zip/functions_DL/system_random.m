function [RZF_results, MRT_results]=system_random(H_bar,Phi,pathloss,somme_pathloss,lambda,Power, rho_training_lin)

[numOfAnt numOfUEs]= size(H_bar{1});
L=length(Phi);
for ii=1:L
    
    Ytr{ii}=zeros(numOfAnt,numOfUEs);
    for jj=1:L
        H{ii,jj}=((randn(numOfAnt,numOfUEs)+1i*randn(numOfAnt,numOfUEs))/sqrt(2))*diag(sqrt(pathloss{ii}(:,jj)));
        if (ii==jj)
            H{ii,ii}=H{ii,ii}+H_bar{ii};
        end
        Ytr{ii}=Ytr{ii}+H{ii,jj};
    end
    Ytr{ii}=Ytr{ii}+1/sqrt(rho_training_lin)*(randn(numOfAnt,numOfUEs)+1i*randn(numOfAnt,numOfUEs))/sqrt(2);
    H_hat{ii}=H_bar{ii}+(Ytr{ii}-H_bar{ii})*diag((pathloss{ii}(:,ii)))./(1/rho_training_lin +ones(numOfAnt,1)*(somme_pathloss{ii})');
    % Cov{ii}=Cov{ii}+ (H_hat{ii}(:,4)-H_bar{ii}(:,4)) *(H_hat{ii}(:,4)-H_bar{ii}(:,4))';
    %  meanH{ii}=meanH{ii}+H_hat{ii};
    W_l_ZF{ii}=inv(H_hat{ii}*H_hat{ii}'+numOfAnt*eye(numOfAnt)*lambda)*H_hat{ii};
    %%%For checking %%%%
    Q{ii}= inv(H_hat{ii}*H_hat{ii}'/numOfAnt+eye(numOfAnt)*lambda);
    beta(ii)=Power/(1/numOfUEs*trace(W_l_ZF{ii}*(W_l_ZF{ii})'));
    W_l_ZF{ii}=sqrt(beta(ii))*W_l_ZF{ii};
    W_l_MRT{ii}=H_hat{ii};
    %%%For checking %%%%
    beta_MRT(ii)=Power/(1/numOfUEs*trace(W_l_MRT{ii}*(W_l_MRT{ii})'));
    W_l_MRT{ii}=sqrt(beta_MRT(ii))*W_l_MRT{ii};
    
    Hcellonly{ii}=H{ii,ii};
end
for  l=1:L
    first_term_interference_emp{l}=0;
    second_term_interference_emp{l}=0;
    third_term_interference_emp{l}=0;
    for lcomp=1:L
        first_term_interference_emp{l}=  first_term_interference_emp{l} +beta(lcomp)*diag((H{lcomp,l})'*Q{lcomp}*H{lcomp,l})/(numOfAnt^2);
        second_term_interference_emp{l}= second_term_interference_emp{l} + beta(lcomp)* abs(diag((H{lcomp,l})'*Q{lcomp}*H_hat{lcomp})).^2 / (numOfAnt^3);
        third_term_interference_emp{l}= third_term_interference_emp{l} + beta(lcomp)* diag((H{lcomp,l})'*Q{lcomp}^2*H{lcomp,l})/(numOfAnt^2);
    end
end

energy_signal_cell=cellfun(@(x,y) (sum(conj(x).*y,1))',Hcellonly,W_l_ZF,'UniformOutput',false);
energy_signal_cell=cellfun(@(x) abs(x).^2,energy_signal_cell,'UniformOutput',false);

energy_signal_cell_MRT=cellfun(@(x,y) (sum(conj(x).*y,1))',Hcellonly,W_l_MRT,'UniformOutput',false);
energy_signal_cell_MRT=cellfun(@(x) abs(x).^2,energy_signal_cell_MRT,'UniformOutput',false);


%%%%% Computation of the pilot contamination term  %%%%%%%%%%%

for l=1:L
    pilot_contamination{l}=0;
    pilot_contamination_MRT{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            pilot_contamination{l}=pilot_contamination{l}+abs(diag(H{lcomp,l}'*W_l_ZF{lcomp})).^2;
            pilot_contamination_MRT{l}= pilot_contamination_MRT{l}+abs(diag(H{lcomp,l}'*W_l_MRT{lcomp})).^2;
        end
    end
end


for l=1:L
    intra_cell_interference_MRT{l} = abs(diag((H{l,l})'*W_l_MRT{l}*(W_l_MRT{l})'*H{l,l}))-diag((H{l,l})'*W_l_MRT{l}).^2;
    
end

for l=1:L
    intra_cell_inter_cell_interference{l}=0;
    intra_cell_inter_cell_interference_MRT{l}=0;
    for lcomp=1:L
        intra_cell_inter_cell_interference{l}= intra_cell_inter_cell_interference{l} +diag((H{lcomp,l})'*W_l_ZF{lcomp}*(W_l_ZF{lcomp})'*H{lcomp,l})-abs(diag(H{lcomp,l}'*W_l_ZF{lcomp})).^2;
        intra_cell_inter_cell_interference_MRT{l}= intra_cell_inter_cell_interference_MRT{l} +diag((H{lcomp,l})'*W_l_MRT{lcomp}*(W_l_MRT{lcomp})'*H{lcomp,l})-abs(diag(H{lcomp,l}'*W_l_MRT{lcomp})).^2;
    end
end
energy_signal_cell=cellfun(@(x) x./(numOfAnt),energy_signal_cell,'UniformOutput',false);
energy_signal_cell_MRT=cellfun(@(x) x./(numOfAnt),energy_signal_cell_MRT,'UniformOutput',false);
pilot_contamination=cellfun(@(x) x./(numOfAnt),pilot_contamination,'UniformOutput',false);
pilot_contamination_MRT=cellfun(@(x) x./(numOfAnt),pilot_contamination_MRT,'UniformOutput',false);
intra_cell_interference_MRT =cellfun(@(x) x./numOfAnt,intra_cell_interference_MRT,'UniformOutput',false);
intra_cell_inter_cell_interference=cellfun(@(x) x./(numOfAnt),intra_cell_inter_cell_interference,'UniformOutput',false);
intra_cell_inter_cell_interference_MRT=cellfun(@(x) x./(numOfAnt),intra_cell_inter_cell_interference_MRT,'UniformOutput',false);

RZF_results.energy_signal_cell=energy_signal_cell;
RZF_results.pilot_contamination= pilot_contamination;
RZF_results.intra_cell_inter_cell_interference= intra_cell_inter_cell_interference;
RZF_results.first_term_interference_emp=first_term_interference_emp;
RZF_results.second_term_interference_emp=second_term_interference_emp;
RZF_results.third_term_interference_emp= third_term_interference_emp;


MRT_results.energy_signal_cell= energy_signal_cell_MRT;
MRT_results.pilot_contamination= pilot_contamination_MRT;
MRT_results.intra_cell_inter_cell_interference= intra_cell_inter_cell_interference_MRT;
MRT_results.intra_cell_interference_MRT=intra_cell_interference_MRT;


%energy_signal_cell,pilot_contamination,intra_cell_inter_cell_interference,first_term_interference_emp,second_term_interference_emp,third_term_interference_emp
