function [total_interference_th,energy_signal_cell_th,Psi_bar,snr_signal_cell_RZF_th]= results_mrt_rzf_th_new_formula(H_bar,Phi,pathloss,some_pathloss,lambda,Power,rho_training_lin,rho_lin)
L=length(Phi);
[numOfAnt numOfUEs]= size(H_bar{1});
delta_tilde_tot=zeros(L,1);
delta_tot=zeros(L,1);
gamma_d_tab=zeros(L,1);
gamma_tilde_d_tab=zeros(L,1);
F=zeros(L,1);
Delta=zeros(L,1);
%ubar=zeros(numOfUEs,L);


for ii=1:L
[delta_tilde,delta,T,T_tilde,Psi,Psi_tilde]=deterministic_matrix(H_bar{ii}/sqrt(numOfAnt),diag(Phi{ii}(:,ii)),lambda);

delta_tilde_tot(ii)=delta_tilde;
delta_tot(ii)=delta;
T_tab{ii}=T;
T_tilde_tab{ii}=T_tilde;
gamma_d_tab(ii)=1/numOfAnt*trace(T^2);
D_tilde=diag(Phi{ii}(:,ii));
gamma_tilde_d_tab(ii)=1/numOfAnt*trace(diag(Phi{ii}(:,ii))*T_tilde*diag(Phi{ii}(:,ii))*T_tilde);
F(ii)=(1/(numOfAnt^2))*trace(T^2*H_bar{ii}*diag((Phi{ii}(:,ii))./((1+delta*Phi{ii}(:,ii)).^2))*H_bar{ii}');
Delta(ii)=(1-F(ii))^2-lambda^2*gamma_d_tab(ii)*gamma_tilde_d_tab(ii);
nu_d(ii)=(1/Delta(ii))*(1/numOfAnt)*trace(T^2);
Psi_bar(ii)=(numOfUEs/numOfAnt) /(delta-lambda*nu_d(ii));
%Psi_bar(ii)=1/(lambda^2*gamma_d_tab(ii)/Delta(ii)*(1/numOfUEs*sum(Phi{ii}(:,ii).*diag(T_tilde^2))) +(1-F(ii))/(Delta(ii)*(1+delta_tilde)^2)*(1/numOfUEs)*(1/numOfAnt)*trace(T_tilde*H_bar{ii}'*H_bar{ii}*T_tilde));
ubar{ii}= 1./(lambda*diag(T_tilde)) -1;
energy_signal_cell_th{ii}=Psi_bar(ii)*ubar{ii}.^2./((1+ubar{ii}).^2);
end
for l=1:L
zeta(:,l)= (1-F(l))/(Delta(l)*numOfAnt)*diag(T_tilde_tab{l}*(H_bar{l})'*H_bar{l}*T_tilde_tab{l})./(lambda^2*diag(T_tilde_tab{l}).^2*(1+delta_tilde_tot(l))^2) +gamma_d_tab(l)/Delta(l)* (diag(T_tilde_tab{l}*diag(Phi{l}(:,l))*T_tilde_tab{l})./(diag(T_tilde_tab{l}).^2)-Phi{l}(:,l));
end
for l=1:L
    pilot_contamination_th{l}=0;
    for lcomp=1:L
         if (lcomp~=l)
        pilot_contamination_th{l} = pilot_contamination_th{l} + Psi_bar(lcomp)*delta_tot(lcomp)^2*Phi{lcomp}(:,l).^2./((1+ubar{lcomp}).^2);
        end
    end
end

for l=1:L
    first_term_inter_intra_interference{l}=0;

for lcomp=1:L
    if (lcomp~=l)
        csi= pathloss{lcomp}(:,l)*delta_tot(lcomp) - lambda * diag(T_tilde_tab{lcomp}).*(Phi{lcomp}(:,l)*delta_tot(lcomp)).^2;
    else
        csi=(pathloss{l}(:,l)-Phi{l}(:,l))*delta_tot(l)+1-lambda*diag(T_tilde_tab{l});
    end
first_term_inter_intra_interference{l}=first_term_inter_intra_interference{l}+csi*Psi_bar(lcomp);
end
end
for l=1:L
third_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            mu=pathloss{lcomp}(:,l) * nu_d(lcomp) - Phi{lcomp}(:,l).^2.*delta_tot(lcomp).*(2*nu_d(lcomp)*(1+ubar{lcomp})-delta_tot(lcomp)*(Phi{lcomp}(:,lcomp)*nu_d(lcomp)+zeta(:,lcomp)))./((1+ubar{lcomp}).^2);
third_term_inter_intra_interference{l}= third_term_inter_intra_interference{l} + Psi_bar(lcomp) *mu;
    else
        mu=pathloss{l}(:,l)*nu_d(l)+zeta(:,l)- ubar{l}.*(Phi{l}(:,l)*nu_d(l)+zeta(:,l)) .* (2+ubar{l})./((1+ubar{l}).^2);
        third_term_inter_intra_interference{l}= third_term_inter_intra_interference{l}+ Psi_bar(l)*mu;
    end
    end

end
for l=1:L
second_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            second_term_inter_intra_interference{l} = second_term_inter_intra_interference{l} +  Psi_bar(lcomp) * (Phi{lcomp}(:,l)*delta_tot(lcomp)./(1+ubar{lcomp})).^2;
    else
         second_term_inter_intra_interference{l}=  second_term_inter_intra_interference{l} +  Psi_bar(lcomp)*(ubar{lcomp}./(1+ubar{lcomp})).^2;
     end
 end
end
for ii=1:L
total_interference_th{ii}= first_term_inter_intra_interference{ii} - lambda* third_term_inter_intra_interference{ii}-second_term_inter_intra_interference{ii} +pilot_contamination_th{ii};
intra_cell_inter_cell_interference_th{ii} = first_term_inter_intra_interference{ii} - lambda* third_term_inter_intra_interference{ii} -second_term_inter_intra_interference{ii};

end
snr_signal_cell_RZF_th=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_th,total_interference_th,'UniformOutput',false);

for ii=1:L
       Theta_bar(ii)=1/(1/numOfUEs*(sum(Phi{ii}(:,ii)) + 1/numOfAnt * trace((H_bar{ii})'*H_bar{ii})));
end

for l=1:L
    energy_signal_cell_MRT_th{l}=Theta_bar(l)*(Phi{l}(:,l)+1/numOfAnt*diag((H_bar{l})'*H_bar{l})).^2;
    pilot_contamination_MRT_th{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            pilot_contamination_MRT_th{l}=pilot_contamination_MRT_th{l}+Theta_bar(lcomp)*Phi{lcomp}(:,l).^2 + 1/numOfAnt * Theta_bar(lcomp)*pathloss{lcomp}(:,l).*(Phi{lcomp}(:,lcomp)+1/numOfAnt*diag((H_bar{lcomp})'*H_bar{lcomp}));

        end
    end
end

for l=1:L
first_term_interference_MRT{l}=0;
    for lcomp=1:L
        first_term_interference_MRT{l}=first_term_interference_MRT{l} + Theta_bar(lcomp)/numOfAnt*(pathloss{lcomp}(:,l)).*(sum(Phi{lcomp}(:,lcomp))-Phi{lcomp}(:,lcomp) + 1/numOfAnt*trace((H_bar{lcomp})'*H_bar{lcomp})-1/numOfAnt*diag((H_bar{lcomp})'*H_bar{lcomp}));
    end
end

for l=1:L
second_term_interference_MRT{l}= 1/(numOfAnt^2)*Theta_bar(l)*(sum(Phi{l}(:,l))*diag((H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).*Phi{l}(:,l)+diag((H_bar{l})'*H_bar{l}*(H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).^2);
end


for l=1:L
    interference_MRT_th{l}= first_term_interference_MRT{l} + second_term_interference_MRT{l};
    total_interference_MRT_th{l}= interference_MRT_th{l} + pilot_contamination_MRT_th{l};
end



snr_signal_cell_MRT_th=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_MRT_th,total_interference_MRT_th,'UniformOutput',false);

