function [snr_signal_cell_RZF_th,snr_signal_cell_MRT_th]= results_mrt_rzf_th(H_bar,Phi,pathloss,some_pathloss,lambda,Power,rho_training_lin,rho_lin)

%%%%%% Equivalent deterministe: Checking of each term %%%%%%%%%%%%%%%%%%%
L=length(Phi);
[numOfAnt numOfUEs]= size(H_bar{1});


delta_tilde_tot=zeros(L,1);
delta_tot=zeros(L,1);
gamma_d_tab=zeros(L,1);
gamma_tilde_d_tab=zeros(L,1);
F=zeros(L,1);
Delta=zeros(L,1);
%ubar=zeros(numOfUEs,L);


for ii=1:L
[delta_tilde,delta,T,T_tilde,Psi,Psi_tilde]=deterministic_matrix(H_bar{ii}/sqrt(numOfAnt),diag(Phi{ii}(:,ii)),lambda);

delta_tilde_tot(ii)=delta_tilde;
delta_tot(ii)=delta;
T_tab{ii}=T;
T_tilde_tab{ii}=T_tilde;
gamma_d_tab(ii)=1/numOfAnt*trace(T^2);
D_tilde=diag(Phi{ii}(:,ii));
gamma_tilde_d_tab(ii)=1/numOfAnt*trace(diag(Phi{ii}(:,ii))*T_tilde*diag(Phi{ii}(:,ii))*T_tilde);
F(ii)=(1/(numOfAnt^2))*trace(T^2*H_bar{ii}*diag((Phi{ii}(:,ii))./((1+delta*Phi{ii}(:,ii)).^2))*H_bar{ii}');
F1(ii)=(1/(numOfAnt^2))*trace(T^2*H_bar{ii}*D_tilde*inv(eye(numOfUEs)+delta*D_tilde)^2*H_bar{ii}');
Delta(ii)=(1-F(ii))^2-lambda^2*gamma_d_tab(ii)*gamma_tilde_d_tab(ii);
nu_d(ii)=(1/Delta(ii))*(1/numOfAnt)*trace(T^2);
Psi_bar(ii)=(numOfUEs/numOfAnt) /(delta-lambda*nu_d(ii)); %%%% Equivalent deterministe of betaii/N ***********Checking DONE **********

%%%% Slow implementation
%for k=1:numOfUEs
 %   ubar(k,ii)= delta_tot(ii)*Phi{ii}(k,ii) + 1/(lambda * T_tilde(k,k)) * (H_bar{ii}(:,k))'*T*H_bar{ii}(:,k) /(numOfAnt*(1+delta*Phi{ii}(k,ii)));
%end

%%%% Fast implementation 
ubar{ii}= delta_tot(ii) * Phi{ii}(:,ii) + (diag(H_bar{ii}'*T*H_bar{ii}).*(1./(lambda*diag(T_tilde))))./(numOfAnt*(1+delta*Phi{ii}(:,ii)));
omega{ii}=delta_tot(ii) * pathloss{ii}(:,ii) + diag(H_bar{ii}'*T*H_bar{ii}).*(1./(lambda*diag(T_tilde)))./(numOfAnt*(1+delta*Phi{ii}(:,ii)));


energy_signal_cell_th{ii}=Psi_bar(ii)*ubar{ii}.^2./((1+ubar{ii}).^2); %%%% Checking of the signal term %%%%%**********Checking DONE **********

end

for l=1:L

zeta(:,l)= (1-F(l))/Delta(l) * (diag(H_bar{l}'*T_tab{l}^2*H_bar{l}).*(1./(lambda*diag(T_tilde_tab{l})).^2))./(numOfAnt*(1+delta_tot(l)*Phi{l}(:,l)).^2);

for k=1:numOfUEs
    for ii=1:numOfUEs
        if (ii~=k)
            zeta(k,l) =zeta(k,l) + gamma_d_tab(l)/Delta(l)*Phi{l}(ii,l)/(1+Phi{l}(ii,l)*delta_tot(l))^2 *(1/(numOfAnt^2)) * (H_bar{l}(:,k))'*T_tab{l}*H_bar{l}(:,ii)*(H_bar{l}(:,ii))'*T_tab{l}*H_bar{l}(:,k)/(lambda^2*(T_tilde_tab{l}(k,k))^2*(1+delta_tot(l)*Phi{l}(k,l))^2);
        end
end
end

end
 %%%%%%%%% Checking of pilot contamination: Some difference due to the fact that the values are small, but I think results are correct  %%%%%%%%%%%
for l=1:L
    pilot_contamination_th{l}=0;
    for lcomp=1:L
         if (lcomp~=l)
        pilot_contamination_th{l} = pilot_contamination_th{l} + Psi_bar(lcomp)*delta_tot(lcomp)^2*Phi{lcomp}(:,l).^2./((1+ubar{lcomp}).^2);
        end
    end
end


%%%%% Checking first term interference  %%%%%%%%%%%%%% %%%%%%%%%%%%% First term checked: Good results %%%%%%%%%%%%%%
for l=1:L
first_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            first_term_inter_intra_interference{l}= first_term_inter_intra_interference{l} + Psi_bar(lcomp)*(pathloss{lcomp}(:,l)*delta_tot(lcomp)-delta_tot(lcomp)^2*Phi{lcomp}(:,l).^2./((1+ubar{lcomp})));
        else
            first_term_inter_intra_interference{l}= first_term_inter_intra_interference{l}+ Psi_bar(l)*(omega{l}-ubar{l}.^2./(1+ubar{l}));
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for l=1:L
second_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            second_term_inter_intra_interference{l} = second_term_inter_intra_interference{l} +  Psi_bar(lcomp) * (Phi{lcomp}(:,l)*delta_tot(lcomp)./(1+ubar{lcomp})).^2;
    else
         second_term_inter_intra_interference{l}=  second_term_inter_intra_interference{l} +  Psi_bar(lcomp)*(ubar{lcomp}./(1+ubar{lcomp})).^2;
     end
 end
end

for l=1:L
third_term_inter_intra_interference{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            mu=pathloss{lcomp}(:,l) * nu_d(lcomp) - Phi{lcomp}(:,l).^2.*delta_tot(lcomp).*(2*nu_d(lcomp)*(1+ubar{lcomp})-delta_tot(lcomp)*(Phi{lcomp}(:,lcomp)*nu_d(lcomp)+zeta(:,lcomp)))./((1+ubar{lcomp}).^2);
third_term_inter_intra_interference{l}= third_term_inter_intra_interference{l} + Psi_bar(lcomp) *mu;
    else
        mu=pathloss{l}(:,l)*nu_d(l)+zeta(:,l)- ubar{l}.*(Phi{l}(:,l)*nu_d(l)+zeta(:,l)) .* (2+ubar{l})./((1+ubar{l}).^2);
        third_term_inter_intra_interference{l}= third_term_inter_intra_interference{l}+ Psi_bar(l)*mu;
    end
    end

end

for ii=1:L
total_interference_th{ii}= first_term_inter_intra_interference{ii} - lambda* third_term_inter_intra_interference{ii}-second_term_inter_intra_interference{ii} +pilot_contamination_th{ii};
intra_cell_inter_cell_interference_th{ii} = first_term_inter_intra_interference{ii} - lambda* third_term_inter_intra_interference{ii} -second_term_inter_intra_interference{ii};

end
snr_signal_cell_RZF_th=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_th,total_interference_th,'UniformOutput',false);

for ii=1:L
       Theta_bar(ii)=1/(1/numOfUEs*(sum(Phi{ii}(:,ii)) + 1/numOfAnt * trace((H_bar{ii})'*H_bar{ii})));
end

for l=1:L
    energy_signal_cell_MRT_th{l}=Theta_bar(l)*(Phi{l}(:,l)+1/numOfAnt*diag((H_bar{l})'*H_bar{l})).^2;
    pilot_contamination_MRT_th{l}=0;
    for lcomp=1:L
        if (lcomp~=l)
            pilot_contamination_MRT_th{l}=pilot_contamination_MRT_th{l}+Theta_bar(lcomp)*Phi{lcomp}(:,l).^2 + 1/numOfAnt * Theta_bar(lcomp)*pathloss{lcomp}(:,l).*(Phi{lcomp}(:,lcomp)+1/numOfAnt*diag((H_bar{lcomp})'*H_bar{lcomp}));

        end
    end
end

for l=1:L
first_term_interference_MRT{l}=0;
    for lcomp=1:L
        first_term_interference_MRT{l}=first_term_interference_MRT{l} + Theta_bar(lcomp)/numOfAnt*(pathloss{lcomp}(:,l)).*(sum(Phi{lcomp}(:,lcomp))-Phi{lcomp}(:,lcomp) + 1/numOfAnt*trace((H_bar{lcomp})'*H_bar{lcomp})-1/numOfAnt*diag((H_bar{lcomp})'*H_bar{lcomp}));
    end
end

for l=1:L
second_term_interference_MRT{l}= 1/(numOfAnt^2)*Theta_bar(l)*(sum(Phi{l}(:,l))*diag((H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).*Phi{l}(:,l)+diag((H_bar{l})'*H_bar{l}*(H_bar{l})'*H_bar{l})-diag((H_bar{l})'*H_bar{l}).^2);
end


for l=1:L
    interference_MRT_th{l}= first_term_interference_MRT{l} + second_term_interference_MRT{l};
    total_interference_MRT_th{l}= interference_MRT_th{l} + pilot_contamination_MRT_th{l};
end



snr_signal_cell_MRT_th=cellfun(@(x,y) x./(y+1/(numOfAnt*rho_lin)),energy_signal_cell_MRT_th,total_interference_MRT_th,'UniformOutput',false);

